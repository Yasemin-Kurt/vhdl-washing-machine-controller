library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.numeric_std.ALL;

entity tanim is
    Port (clk,rst : in std_logic;
    kapak_kontrol : in std_logic;
    deterjan_kontrol: in std_logic;
    program_sec_giris : in std_logic_vector(0 to 3);
    --pamuklu 0000,sentetik 0001, mix 0010, hassas_ipek 0011, elde_yikama 0100, kot 0101, alerji_bebek 0110, spor 0111, gomlek 1000, hizli 1001
    on_yikama_sec : in std_logic;
    durulama_sec : in std_logic; 
    sicaklik_sec : in std_logic_vector(0 to 2);
    g_skma : inout integer :=0;
    g_durula : inout integer :=0 ;
    g_yika : inout integer :=0;
    mevcut_sure_durumu : out integer := 0;
    cikis : out std_logic);
end tanim;

architecture davranis of tanim is
    Type islem is (basla, su_al1, su_al2, su_al3, su_al4, su_ver1, su_ver2, su_ver3, su_ver4, on_yika, yika, det_al, durula, eks_durula, skma);
    Signal simdiki_durum:islem;
    Signal sayici5 : integer := 0;
    Signal sayici15 : integer := 0;
    Signal sayici3 : integer := 0;
    Signal sayici_durula : integer := 0;
    Signal sayici_yika : integer := 0 ;
    Signal sayici_skma : integer := 0;
    Signal sonuc_on_yika : std_logic ;
    Signal sonuc_eks_durulama : std_logic ;
    Signal son_sicaklik : std_logic_vector(0 to 2); -- 000 20derece, 001 30derece, 010 40 derece, 011 60 derece, 100 90 derece, 101 * derece
    Signal program_sec_cikis : std_logic_vector(0 to 3);
    Signal deterjan_var_mi : std_logic;
    constant max_sayici_deger5 : integer := 5;
    constant max_sayici_deger15 : integer := 15;
    constant max_sayici_deger3 : integer := 3;
    signal max_sayici_deger_durula : integer := 0;
    signal max_sayici_deger_yika : integer := 0;
    signal max_sayici_deger_skma : integer := 0;
    
    
    procedure programlar(
        signal son_sicaklik : out std_logic_vector;
        signal program_sec_cikis : out std_logic_vector;
        signal program_sec_giris : in std_logic_vector;
        signal sicaklik_sec : in std_logic_vector;
        signal g_durula : inout integer;
        signal g_yika : inout integer;
        signal g_skma : inout integer) is
    
    begin
    
        if(program_sec_giris= "0000") then -- se�ilen program pamukluysa
                    program_sec_cikis <="0000";
                    g_durula <= 10; --10dk durulama i�lemi
                    g_skma <= 10;    --skma i�in 10dk gecikme
                            
                            if(sicaklik_sec = "000") then --s�cakl�k 20 derece ise
                            son_sicaklik <= "000";
                            g_yika <= 40;    --yika i�in 40dk gecikme
                            
                            elsif(sicaklik_sec = "010") then --s�cakl�k 40 derece ise
                            son_sicaklik <= "010";
                            g_yika <= 45;    --yika i�in 45dk gecikme
                              
                            elsif(sicaklik_sec = "011") then --s�cakl�k 60 derece ise
                            son_sicaklik <= "011"; 
                            g_yika <= 55;    --yika i�in 55dk gecikme 
                           
                            elsif(sicaklik_sec = "100") then --s�cakl�k 90 derece ise
                            son_sicaklik <= "100";
                            g_yika <= 70;    --yika i�in 70dk gecikme
                            end if;
                         
                 elsif(program_sec_giris="0001") then --se�ilen program sentetikse
                            program_sec_cikis <= "0001";
                            if(sicaklik_sec = "001") then --s�cakl�k 30 derece ise
                            son_sicaklik <= "001";
                            g_yika <= 35;    --yika i�in 35dk gecikme
                             g_durula <= 10;    --durula i�in 10dk gecikme
                             g_skma<= 8;    --skma i�in 8dk gecikme
                             
                             elsif(sicaklik_sec = "010") then --s�cakl�k 40 derece ise
                             son_sicaklik <= "010";
                             g_yika <= 35;    --yika i�in 35dk gecikme
                             g_durula <= 10;    --durula i�in 10dk gecikme
                             g_skma <= 8;    --skma i�in 8dk gecikme
                             end if; 
                             
                  elsif(program_sec_giris="0010") then -- se�ilen program mixse (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "0010";
                             son_sicaklik <= "010"; --s�cakl�k sabit 40 derece
                             g_yika <= 40;    --yika i�in 40dk gecikme
                             g_durula <= 10;    --durula i�in 10dk gecikme
                             g_skma <= 10;    --skma i�in 10dk gecikme
                          
                  elsif(program_sec_giris="0011") then -- se�ilen program hassas/ipekse (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "0011";
                             son_sicaklik <= "001"; --s�cakl�k sabit 30 derece
                             g_yika <= 25;    --yika i�in 25dk gecikme
                             g_durula <= 8;    --durula i�in 8dk gecikme
                             g_skma <= 5;    --skma i�in 5dk gecikme
                
                 elsif(program_sec_giris="0100") then -- se�ilen program elde y�kama ise (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "0100";
                             son_sicaklik <= "001"; --s�cakl�k sabit 30 derece
                             g_yika <= 35;    --yika i�in 35dk gecikme
                             g_durula <= 8;    --durula i�in 8dk gecikme
                             g_skma <= 5;    --skma i�in 5dk gecikme
                
                 elsif(program_sec_giris="0101") then -- se�ilen program kot/koyu renk ise (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "0101";
                             son_sicaklik <= "010"; --s�cakl�k sabit 40 derece
                             g_yika <= 50;    --yika i�in 50dk gecikme
                             g_durula <= 10;    --durula i�in 10dk gecikme
                             g_skma <= 12;    --skma i�in 12dk gecikme
                             
                 elsif(program_sec_giris="0110") then -- se�ilen program alerji/bebek (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "0110";
                             son_sicaklik <= "011"; --s�cakl�k sabit 60 derece
                             g_yika <= 55;    --yika i�in 55dk gecikme
                             g_durula <= 16;    --durula i�in 16dk gecikme
                             g_skma <= 12;    --skma i�in 12dk gecikme
               
                 elsif(program_sec_giris="0111") then -- se�ilen program spor ise (�n y�kama var eks durulama var durumu)
                             program_sec_cikis<="0111";
                             son_sicaklik <= "001"; --s�cakl�k sabit 30 derece
                             g_yika <= 30;    --yika i�in 30dk gecikme
                             g_durula <= 10;    --durula i�in 10dk gecikme
                             g_skma <= 8;    --skma i�in 8dk gecikme
                
                  elsif(program_sec_giris="1000") then -- se�ilen program g�mlekse (�n y�kama var eks durulama var durumu)
                             program_sec_cikis <= "1000";
                             son_sicaklik <= "010"; --s�cakl�k sabit 40 derece
                             g_yika <= 35;    --yika i�in 35dk gecikme
                             g_durula <= 8;    --durula i�in 8dk gecikme
                             g_skma <= 8;    --skma i�in 8dk gecikme
                 
                  elsif(program_sec_giris="1001") then --se�ilen program h�zl� ise (�n y�kama ve eks durulama var durumu)
                  g_durula <= 5;    --durula i�in 5dk gecikme burada tan�mlayabiliriz t�m s�cakl�klarda sbt
                  g_skma <= 5;    --skma i�in 5dk gecikme burada tan�mlayabiliriz t�m s�cakl�klarda sbt
                  program_sec_cikis <= "1001";
                             if(sicaklik_sec = "010") then --s�cakl�k 40 derece ise
                             son_sicaklik <= "010";
                              g_yika <= 20;    --yika i�in 20dk gecikme
                             elsif(sicaklik_sec = "101") then    --s�cakl�k * derece ise
                             son_sicaklik <= "101";
                              g_yika <= 14;    --yika i�in 16dk gecikme
                             end if; 
                             
                             else
                             program_sec_cikis <= "UUUU";
                             son_sicaklik <= "UUU";
                             g_durula <= 0;
                             g_skma <= 0;
                             g_yika <= 0;
                             
                   end if; --program se� i�in
      end procedure;
          
        
begin --architecture i�in

  
  process (clk,rst, program_sec_giris, sicaklik_sec, g_durula, g_skma, g_yika)
  begin --process i�in
  
  programlar(
                son_sicaklik,
                program_sec_cikis,
                program_sec_giris,
                sicaklik_sec,
                g_durula, -- inout sinyali
                g_yika, -- inout sinyali
                g_skma -- inout sinyali
            );
            
  
  max_sayici_deger_skma <= g_skma;
  max_sayici_deger_durula <= g_durula;
  max_sayici_deger_yika <= g_yika;
            
    if rst = '1' then
    
        program_sec_cikis <= "UUUU";
        cikis <= '0';
        sayici5 <=0;
        sayici3 <=0;
        sayici15 <=0;
        sayici_durula <=0;
        sayici_yika <=0;
        sayici_skma <=0;
        
        
    elsif rising_edge(clk) then --clk y�kselen kenar�nda
    
    
      if(kapak_kontrol='1') then --e�er kapak kapal�ysa
    
            sonuc_eks_durulama <= durulama_sec;
            sonuc_on_yika <= on_yikama_sec;
            deterjan_var_mi <= deterjan_kontrol;
            
            simdiki_durum <= basla;
                      
                            case simdiki_durum is
                            
                            when basla =>
                            mevcut_sure_durumu <= 0;
                            simdiki_durum <= su_al1;
                            cikis <= '0';
                            
                            when su_al1 =>
                                    if (sonuc_on_yika ='1') then
                                        if (sayici5 < max_sayici_deger5) then
                                        sayici5 <= sayici5 + 1;
                                        mevcut_sure_durumu <= sayici5;
                                        simdiki_durum <= su_al1;
                                        else
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 5;
                                       sayici5 <= 0;
                                       simdiki_durum <= on_yika;
                                        end if; 
                                    else --sonuc onyika 0 ise
                                    cikis <= '0';
                                    mevcut_sure_durumu <= 0;
                                    simdiki_durum <= on_yika;
                                    end if;
                             when on_yika =>
                            if (sonuc_on_yika ='1') then
                                if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= on_yika;
                                        else
                                        sayici15 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 15;
                                        simdiki_durum <= su_ver1;
                                        end if;
                            else
                            cikis <= '0';
                            simdiki_durum <= su_ver1;
                            end if;
                            
                            when su_ver1 =>
                                    if(sonuc_on_yika='1') then
                                        if (sayici5 < max_sayici_deger5) then
                                        sayici5 <= sayici5 + 1;
                                        mevcut_sure_durumu <= sayici5;
                                        simdiki_durum <= su_ver1;
                                        else
                                        sayici5 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 5;
                                        simdiki_durum <= su_al2;
                                        end if;
                                    else
                                    cikis <= '0';
                                    mevcut_sure_durumu <= 0;
                                    simdiki_durum <= su_al2;
                                    end if;
                                    
                           when su_al2 =>
                                    if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= su_al2;
                                        else
                                        cikis <= '0';
                                        sayici15 <= 0;
                                        mevcut_sure_durumu <= 15;
                                        simdiki_durum <= yika;
                                        end if;
                         
                         when yika =>
                                if (sayici_yika < max_sayici_deger_yika) then
                                        sayici_yika <= sayici_yika + 1;
                                        mevcut_sure_durumu <= sayici_yika;
                                        simdiki_durum <= yika;
                                        else
                                        sayici_yika <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= max_sayici_deger_yika;
                                        simdiki_durum <= det_al;
                                        end if;
                       
                       when det_al =>
                                if (sayici3 < max_sayici_deger3) then
                                        sayici3 <= sayici3 + 1;
                                        mevcut_sure_durumu <= sayici3;
                                        simdiki_durum <= det_al;
                                        else
                                        sayici3 <= 0;
                                        cikis  <= '0';
                                        mevcut_sure_durumu <= 3;
                                        simdiki_durum <= su_ver2;
                                        end if;
                       when su_ver2 =>
                                    if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= su_ver2;
                                        else
                                       sayici15 <= 0;
                                       cikis <= '0';
                                       mevcut_sure_durumu <= 15;
                                       simdiki_durum <= su_al3;
                                       end if;
                                                                               
                      when su_al3 =>
                                    if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= su_al3;
                                        else
                                        sayici15 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <=  15;
                                        simdiki_durum <= durula;
                                        end if;
                                    
                     when durula =>
                                if (sayici_durula < max_sayici_deger_durula) then
                                        sayici_durula <= sayici_durula + 1;
                                        mevcut_sure_durumu <= sayici_durula;
                                        simdiki_durum <= durula;
                                        else
                                         sayici_durula <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= max_sayici_deger_durula;
                                        simdiki_durum <= su_ver3;
                                        end if;    
                    
                    when su_ver3 =>
                                    if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= su_ver3;
                                        else
                                        sayici15 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 15;
                                        simdiki_durum <= su_al4;
                                        end if;
                                                  
                   when su_al4 =>
                                    if (sonuc_eks_durulama ='1') then
                                       if (sayici5 < max_sayici_deger5) then
                                        sayici5 <= sayici5 + 1;
                                        mevcut_sure_durumu <= sayici5;
                                        simdiki_durum <= su_al4;
                                        else
                                        sayici5 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 5;
                                        simdiki_durum <= eks_durula;
                                        end if;
                                   else
                                        cikis <= '0';
                                        simdiki_durum <= eks_durula;
                                   end if;
                  
                  when eks_durula =>
                            if (sonuc_eks_durulama = '1' ) then
                                if (sayici15 < max_sayici_deger15) then
                                        sayici15 <= sayici15 + 1;
                                        mevcut_sure_durumu <= sayici15;
                                        simdiki_durum <= eks_durula;
                                        else
                                        sayici15 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 15;
                                        simdiki_durum <= su_ver4;
                                        end if;
                            else 
                            cikis <= '0';
                            mevcut_sure_durumu <= 0;
                            simdiki_durum <= su_ver4;
                            end if;
                                    
                 when su_ver4 =>
                                    if(sonuc_eks_durulama='1') then
                                        if (sayici5 < max_sayici_deger5) then
                                        sayici5 <= sayici5 + 1;
                                        mevcut_sure_durumu <= sayici5;
                                        simdiki_durum <= su_ver4;
                                        else
                                        sayici5 <= 0;
                                        cikis <= '0';
                                        mevcut_sure_durumu <= 5;
                                        simdiki_durum <= skma;
                                        end if; 
                                    else
                                    cikis <= '0';
                                    mevcut_sure_durumu <= 0;
                                    simdiki_durum <= skma;
                                    end if;
                            
                when skma =>
                                if (sayici_skma < max_sayici_deger_skma) then
                                        sayici_skma <= sayici_skma + 1;
                                          mevcut_sure_durumu <= sayici_skma;
                                          simdiki_durum <= skma;
                                        else
                                        sayici_skma <= 0;
                                        mevcut_sure_durumu <= max_sayici_deger_skma;
                                        cikis <= '1';
                                        simdiki_durum <= basla;
                                        end if;
                                 
                when others =>
                            cikis <= '0';
                            mevcut_sure_durumu <= 0;
                            simdiki_durum <= basla;
                            end case;
                
              elsif(kapak_kontrol='0') then
              cikis <= '0';
              program_sec_cikis <= "UUUU";
              son_sicaklik <= "UUU";
             end if;--kapak_kontrol  i�in if
      end if; --if(rising_clk) i�in             
  end process;
end davranis;
