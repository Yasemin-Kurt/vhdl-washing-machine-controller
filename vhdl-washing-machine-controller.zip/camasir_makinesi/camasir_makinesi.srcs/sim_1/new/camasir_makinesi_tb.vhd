library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;

entity tanim_tb is
end;

architecture bench of tanim_tb is

  component tanim
      Port (clk,rst : in std_logic;
      kapak_kontrol : in std_logic;
      deterjan_kontrol: in std_logic;
      program_sec_giris : in std_logic_vector(0 to 3);
      on_yikama_sec : in std_logic;
      durulama_sec : in std_logic; 
      sicaklik_sec : in std_logic_vector(0 to 2);
      g_skma : inout integer :=0;
      g_durula : inout integer :=0 ;
      g_yika : inout integer :=0;
      mevcut_sure_durumu : out integer :=0;
      cikis : out std_logic);
  end component;

  signal clk,rst: std_logic;
  signal kapak_kontrol: std_logic;
  signal deterjan_kontrol: std_logic;
  signal program_sec_giris: std_logic_vector(0 to 3);
  signal on_yikama_sec: std_logic;
  signal durulama_sec: std_logic;
  signal sicaklik_sec: std_logic_vector(0 to 2);
  signal g_skma: integer :=0;
  signal g_durula: integer :=0;
  signal g_yika: integer :=0;
  signal cikis: std_logic;
  signal mevcut_sure_durumu : integer := 0;

  constant clock_period: time := 2 ns;
  signal stop_the_clock: boolean;

begin

  uut: tanim port map ( clk               => clk,
                        rst               => rst,
                        kapak_kontrol     => kapak_kontrol,
                        deterjan_kontrol  => deterjan_kontrol,
                        program_sec_giris => program_sec_giris,
                        on_yikama_sec     => on_yikama_sec,
                        durulama_sec      => durulama_sec,
                        sicaklik_sec      => sicaklik_sec,
                        g_skma            => g_skma,
                        g_durula          => g_durula,
                        g_yika            => g_yika,
                        mevcut_sure_durumu => mevcut_sure_durumu,
                        cikis             => cikis );

  stimulus: process
  begin

    -- Put initialisation code here
    
    
    ------------------------------
    -- reset durumu
    rst <= '1';
    wait for 40 ns;
    rst <= '0';
    wait for 40 ns;
    
    ------------------------------
    -- pamuklu 20 derece �n y�kama ve ekstra durulama var durumu
    kapak_kontrol    <= '1';
    deterjan_kontrol <= '1';
    durulama_sec     <= '1';
    on_yikama_sec    <= '1';
    program_sec_giris <= "0000";
    sicaklik_sec      <= "000";
    wait for 375 ns;
    
    ------------------------------
    -- sentetik 30 derece �n y�kama var, ekstra durulama yok durumu
    kapak_kontrol    <= '1';
    deterjan_kontrol <= '0';
    durulama_sec     <= '0';
    on_yikama_sec    <= '0';
    program_sec_giris <= "0100";
    sicaklik_sec      <= "001";
    wait for 260 ns;
 
    
    

    -- Put test bench stimulus code here

    stop_the_clock <= true;
    wait;
  end process;

  clocking: process
  begin
    while not stop_the_clock loop
      clk <= '0', '1' after clock_period / 2;
      wait for clock_period;
    end loop;
    wait;
  end process;

end;