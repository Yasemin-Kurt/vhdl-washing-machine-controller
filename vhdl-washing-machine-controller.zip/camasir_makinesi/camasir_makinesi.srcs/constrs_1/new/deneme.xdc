# Saat pinini tan�mlama
set_property PACKAGE_PIN <pin_number> [get_ports clk_in]
set_property IOSTANDARD LVCMOS33 [get_ports clk_in]

# ��k�� saat pinini tan�mlama (1 Hz ��k��� i�in)
set_property PACKAGE_PIN <pin_number_out> [get_ports clk_out]
set_property IOSTANDARD LVCMOS33 [get_ports clk_out]

# Saat sinyali i�in zamanlama k�s�tlamas�
create_clock -period 10 [get_pins clk_in]  # 100 MHz'lik saat
